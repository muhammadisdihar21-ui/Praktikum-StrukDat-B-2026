mahasiswa = ("A001", "Budi", "Informatika")

print(mahasiswa)

for x in mahasiswa:
    print(x)